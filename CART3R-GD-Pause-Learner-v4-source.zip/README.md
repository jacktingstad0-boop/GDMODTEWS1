# CART3R Pause Learner v4.0

Windows x64 Geode source project. Targets Geode 5.11.2 / GD 2.2081, the loader version you supplied. The build is not verified on Windows or in game. This ZIP is source, not an installable mod. Do not rename it to .geode.

## Build without installing the CLI on your PC
1. Create a private GitHub repository. Extract this ZIP, and upload all its contents to the repository root, including the hidden `.github/workflows/build.yml` file (GitHub's browser upload may omit hidden folders; create that file separately if needed).
2. Enable Actions if prompted. Open Actions > Build CART3R Windows mod > Run workflow. The push to main also triggers a build.
3. On a successful run, download CART3R-Pause-Learner-Windows under Artifacts. Extract the artifact and copy the actual `cart3r.pauselearner.geode` file to the game's `geode/mods` folder while GD is closed. Do not copy this source ZIP there.
4. If the action fails, retain the build log; there is no compiled mod in this source package.

## In-game use (intended behavior, not game tested)
- Start a classic level, enter Practice Mode, disable automatic checkpoints, remove existing checkpoints, enable automatic retry. Avoid StartPos, platformer, and replay modes.
- Press Esc. The CART3R LEARNER panel appears at the lower-right. Learn starts a fresh practice attempt. Replay uses the best saved route. Stop releases learner input and stops training. The panel displays attempts and best percentage each time you pause.
- Deaths are captured by the game callback; built-in auto-retry begins the next candidate attempt. Routes are stored in the mod save directory by level content. Learning stops on practice completion, level exit, checkpoint creation or leaving practice mode. Disable overlapping Mega Hack automation (e.g. macros or noclip) to prevent conflicting results. Use for local practice only, not verified completions.
- Search is stochastic and may stall on difficult sections; this is not a universal solver. No standalone app, external input driver, or calibration is used.

## Local development (optional)
Install Geode CLI and SDK 5.11.2 and a matching Windows C++ toolchain; then run `geode build` from the repository root. See https://docs.geode-sdk.org/getting-started/sdk .

## Test
`g++ -std=c++17 tests/learner_test.cpp -o learner-test && ./learner-test` exercises the portable route learner, not the Geode hooks.
