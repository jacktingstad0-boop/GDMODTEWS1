#include "../src/learner.hpp"
#include <cassert>
#include <iostream>
int main(){using namespace cart3r;auto r=normalize({{.1,.2},{.15,.3},{.6,.7}});assert(r.size()==2&&held(r,.18)&&!held(r,.4));Learner l;l.rng.seed(42);assert(l.finish(5,.6));for(int i=0;i<10000;i++){l.next();for(auto p:l.trial)assert(p.start>=0&&p.end>p.start);double p=held(l.trial,.45)?10:5;l.finish(p,.6);}assert(l.score==10);l.next(true);assert(l.trial.size()==l.best.size());std::cout<<"PASS: normalization, candidate generation, score improvement, replay\n";}
