#pragma once
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>
#include <cstdint>
namespace cart3r {
struct Pulse { double start, end; };
using Route=std::vector<Pulse>;
inline bool held(Route const& r,double t){for(auto const& p:r){if(p.start>t)break;if(t<p.end)return true;}return false;}
inline Route normalize(Route r){
 for(auto& p:r){p.start=std::max(0.,p.start);p.end=std::max(p.start+.025,p.end);}
 std::sort(r.begin(),r.end(),[](auto a,auto b){return a.start<b.start;});
 Route out;for(auto p:r){if(!std::isfinite(p.start)||!std::isfinite(p.end)||p.end>7200)continue;if(!out.empty()&&p.start<out.back().end+.025){out.back().end=std::max(out.back().end,p.end);}else out.push_back(p);}return out;
}
struct Learner {
 std::mt19937 rng{std::random_device{}()}; Route best,trial; double score=-1,death=0; unsigned attempts=0;
 double rand(double a,double b){return std::uniform_real_distribution<double>(a,b)(rng);}
 void next(bool replay=false){trial=best;if(replay||score>=100)return;double window=rand(.25,1.4);if(attempts%13==0)window=rand(1.4,3.);
 double cutoff=std::max(0.,death-window);int kind=int(rand(0,4));
 if(kind==0&&!trial.empty()) {auto i=trial.size()-1;double shift=rand(-.22,.22);trial[i].start+=shift;trial[i].end+=shift;}
 else if(kind==1&&!trial.empty()){trial.back().end+=rand(-.18,.45);}
 else {trial.erase(std::remove_if(trial.begin(),trial.end(),[&](auto p){return p.start>=cutoff;}),trial.end());if(!trial.empty()&&trial.back().end>cutoff)trial.back().end=cutoff;double t=rand(cutoff,std::max(cutoff+.03,death+.12));double duration=rand(.035,rand(0,1)<.25?.8:.22);trial.push_back({t,t+duration});if(kind==3)trial.push_back({t+duration+rand(.05,.25),t+duration+rand(.27,.5)});}
 trial=normalize(trial);
 }
 bool finish(double p,double t){if(!std::isfinite(p)||!std::isfinite(t)||t<0)return false;attempts++;if(p>score+.001||(std::abs(p-score)<=.001&&t>death+.015)){score=std::clamp(p,0.,100.);death=t;best=trial;return true;}return false;}
};
}
