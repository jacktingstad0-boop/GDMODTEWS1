#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include "learner.hpp"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace geode::prelude;
namespace fs = std::filesystem;
namespace {
enum class Mode { Off, Learn, Replay };
std::string keyFor(GJGameLevel* level) {
    if (!level) return {};
    uint64_t h = 14695981039346656037ull;
    auto data = std::string(level->m_levelName.c_str()) + "\n" + std::string(level->m_levelString.c_str());
    for (unsigned char c : data) { h ^= c; h *= 1099511628211ull; }
    std::ostringstream out; out << std::hex << h; return out.str();
}
fs::path routePath(std::string const& key) {
    return Mod::get()->getSaveDir() / (key + ".route");
}
void saveRoute(std::string const& key, cart3r::Learner const& l) {
    if (key.empty()) return;
    std::ofstream out(routePath(key), std::ios::trunc);
    if (!out) { log::warn("Could not save practice route"); return; }
    out << std::setprecision(17) << l.score << ' ' << l.death << ' ' << l.attempts << '\n';
    for (auto p : l.best) out << p.start << ' ' << p.end << '\n';
}
void loadRoute(std::string const& key, cart3r::Learner& l) {
    if (key.empty()) return;
    std::ifstream in(routePath(key));
    double score, death; unsigned attempts;
    if (!(in >> score >> death >> attempts) || !std::isfinite(score) || !std::isfinite(death)
        || score < 0 || score > 100 || death < 0 || death > 7200) return;
    l.score = score; l.death = death; l.attempts = attempts;
    cart3r::Pulse p;
    while (l.best.size() < 100000 && in >> p.start >> p.end) {
        if (std::isfinite(p.start) && std::isfinite(p.end) && p.start >= 0 && p.end <= 7200 && p.end > p.start) l.best.push_back(p);
    }
    l.best = cart3r::normalize(l.best);
}
}
class $modify(Cart3rPlay, PlayLayer) {
    struct Fields {
        cart3r::Learner learner;
        std::string key;
        Mode mode = Mode::Off;
        bool active = false, down = false, done = false;
        double elapsed = 0;
    };
    bool eligible() {
        return m_level && m_player1 && m_isPracticeMode && !m_isPlatformer && !m_useReplay
            && !m_startPosObject && (!m_checkpointArray || m_checkpointArray->count() == 0);
    }
    void loadCurrent() {
        auto key = keyFor(m_level);
        if (key == m_fields->key) return;
        m_fields->key = key;
        m_fields->learner = cart3r::Learner{};
        loadRoute(key, m_fields->learner);
    }
    void releaseInput() {
        if (m_fields->down) { m_fields->down = false; handleButton(false, 1, true); }
    }
    void stopLearner() {
        releaseInput(); m_fields->mode = Mode::Off; m_fields->active = false;
    }
    bool arm(Mode mode) {
        stopLearner(); loadCurrent();
        if (!eligible()) return false;
        if (mode == Mode::Replay && m_fields->learner.score < 0) return false;
        if (mode == Mode::Learn && m_fields->learner.score >= 100) return false;
        m_fields->mode = mode; return true;
    }
    std::string summary() {
        loadCurrent();
        auto const& l = m_fields->learner;
        std::ostringstream s;
        s << (m_fields->mode == Mode::Learn ? "LEARNING" : m_fields->mode == Mode::Replay ? "REPLAY" : "IDLE")
          << "  |  " << l.attempts << " tries\nBest: " << std::fixed << std::setprecision(2) << std::max(0., l.score) << "%";
        return s.str();
    }
    void togglePracticeMode(bool practice) {
        if (!practice) stopLearner();
        PlayLayer::togglePracticeMode(practice);
    }
    void resetLevel() {
        releaseInput(); m_fields->active = false;
        PlayLayer::resetLevel();
        auto f = m_fields.operator->();
        f->done = false; f->elapsed = 0;
        if (f->mode == Mode::Off) return;
        if (!eligible() || getCurrentPercent() > 1.f) { stopLearner(); return; }
        loadCurrent();
        if (f->mode == Mode::Learn && f->learner.score >= 100) { stopLearner(); return; }
        if (f->learner.score < 0) f->learner.trial.clear();
        else f->learner.next(f->mode == Mode::Replay);
        f->active = true;
    }
    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        auto f = m_fields.operator->();
        if (!f->active) return;
        if (!eligible()) { stopLearner(); return; }
        if (!m_started || m_player1->m_isDead || m_hasCompletedLevel || m_isPaused) return;
        if (std::isfinite(dt) && dt > 0) f->elapsed += dt;
        if (f->elapsed > 7200) { stopLearner(); return; }
        bool want = cart3r::held(f->learner.trial, f->elapsed);
        if (want != f->down) { f->down = want; handleButton(want, 1, true); }
    }
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        auto f = m_fields.operator->();
        bool wasActive = f->active && eligible() && !f->done;
        float percent = wasActive ? getCurrentPercent() : 0.f;
        PlayLayer::destroyPlayer(player, object);
        if (!wasActive || f->done || !player || !player->m_isDead) return;
        f->done = true; f->active = false; releaseInput();
        if (f->mode == Mode::Learn) {
            f->learner.finish(percent, f->elapsed); saveRoute(f->key, f->learner);
        }
        // The game's own auto-retry calls resetLevel; no duplicate restart timer.
    }
    void levelComplete() {
        auto f = m_fields.operator->();
        if (f->active && eligible() && !f->done && f->mode == Mode::Learn) {
            f->learner.finish(100, f->elapsed); saveRoute(f->key, f->learner);
        }
        stopLearner();
        PlayLayer::levelComplete();
    }
    void onExit() { stopLearner(); PlayLayer::onExit(); }
};

class $modify(Cart3rPause, PauseLayer) {
    struct Fields { CCLabelBMFont* status = nullptr; };
    Cart3rPlay* play() { return static_cast<Cart3rPlay*>(PlayLayer::get()); }
    void refresh() {
        if (auto p = play(); p && m_fields->status) m_fields->status->setString(p->summary().c_str());
    }
    void addAction(CCMenu* menu, char const* label, float x, float y, SEL_MenuHandler callback) {
        auto spr = ButtonSprite::create(label);
        spr->setScale(.44f);
        auto btn = CCMenuItemSpriteExtra::create(spr, this, callback);
        btn->setPosition({x, y}); menu->addChild(btn);
    }
    void customSetup() {
        PauseLayer::customSetup();
        if (!play()) return;
        auto size = CCDirector::sharedDirector()->getWinSize();
        auto panel = CCLayerColor::create(ccc4(15, 4, 8, 245), 150.f, 88.f);
        panel->setID("cart3r-pause-panel"_spr);
        panel->setPosition({size.width - 158.f, 8.f});
        auto border = CCLayerColor::create(ccc4(230, 24, 65, 255), 150.f, 2.f);
        border->setPosition({0, 86}); panel->addChild(border);
        auto title = CCLabelBMFont::create("CART3R LEARNER", "bigFont.fnt");
        title->setScale(.36f); title->setColor(ccc3(255, 70, 99));
        title->setPosition({75, 75}); panel->addChild(title);
        auto status = CCLabelBMFont::create("IDLE", "chatFont.fnt");
        status->setScale(.55f); status->setPosition({75, 53}); panel->addChild(status);
        m_fields->status = status;
        auto menu = CCMenu::create(); menu->setPosition({0, 0}); panel->addChild(menu, 1);
        addAction(menu, "Learn", 28, 19, menu_selector(Cart3rPause::onLearn));
        addAction(menu, "Replay", 76, 19, menu_selector(Cart3rPause::onReplayRoute));
        addAction(menu, "Stop", 124, 19, menu_selector(Cart3rPause::onStop));
        addChild(panel, 100);
        refresh();
    }
    void startMode(Mode mode) {
        auto p = play(); if (!p) return;
        if (!p->eligible()) {
            FLAlertLayer::create("CART3R", "Use classic Practice Mode from the start. Disable auto checkpoints and remove existing checkpoints. No platformer or StartPos support.", "OK")->show(); return;
        }
        if (!p->arm(mode)) {
            FLAlertLayer::create("CART3R", "No route to replay, or this practice route is already complete.", "OK")->show(); refresh(); return;
        }
        // Native pause restart closes the menu and starts from the beginning.
        PauseLayer::onRestart(nullptr);
    }
    void onLearn(CCObject*) { startMode(Mode::Learn); }
    void onReplayRoute(CCObject*) { startMode(Mode::Replay); }
    void onStop(CCObject*) { if (auto p = play()) p->stopLearner(); refresh(); }
};
